
const MegaBoost = ({handleClick}) => {
    console.log("Megaboost is called");
    return(
        <button onClick={handleClick}>
            Mega Boost
        </button>
    )
}

export default MegaBoost;