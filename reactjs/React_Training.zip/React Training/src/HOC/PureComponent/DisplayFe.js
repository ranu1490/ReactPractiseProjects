export const DisplayFE = ({ searchedFrontend }) => {
    console.log('DisplayFE Without Memo is rendered with ',
        searchedFrontend);
    return (
        <h1> Searched Frontend is {searchedFrontend}</h1>
    )
}