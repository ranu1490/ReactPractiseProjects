export const Conrenderingfn =()=>
{
    let flag = true;
    return(
        <div>
            {flag && <p>I am conditionally rendered in Conrenderingfn</p>}
        </div>   
    )
    return 
}