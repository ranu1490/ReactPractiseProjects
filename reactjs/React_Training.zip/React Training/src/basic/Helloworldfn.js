/*const Helloworldfn =()=>
{
    return <h1>Hello from functional component</h1>
}

//default Export -> at the time of import curly braces not required and it should be only one 
export default Helloworldfn;*/


//named export -> at the time of import curly braces required and it should be as many we want
export const Helloworldfn =()=>
{
    return <h1>Hello from functional component</h1>
}


