import React from 'react';

export default class Helloworldcls extends React.Component
{
    render()
    {
        return (<h1>Hello from class component</h1>);
    }
}